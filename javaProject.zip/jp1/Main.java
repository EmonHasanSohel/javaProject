import frames.RegistrationFrame;

public class Main {
    public static void authenticate_gui() {
        RegistrationFrame frame = new RegistrationFrame();

        frame.showFrame();
        
        // System.out.println("DISPOSED");
    }
    public static void main(String[] args) {
        authenticate_gui();
    }
}