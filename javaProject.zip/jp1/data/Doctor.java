package data;

public class Doctor extends User {
    public Doctor(String username, String password, String name, String email, String location, String NID, String dateOfBirth) {
        super(username, password, name, email, "doctor", location, NID, dateOfBirth);
    }
}