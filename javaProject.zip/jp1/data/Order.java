package data;

public class Order {
    private Service service;
    private User patient;
    private User doctor;
    private String location;
    private String phone;
    private double cost; // New attribute

    // Constructor
    public Order(Service service, User patient, User doctor, String location, String phone, double cost) {
        this.service = service;
        this.patient = patient;
        this.doctor = doctor;
        this.location = location;
        this.phone = phone;
        this.cost = cost; // Initialize cost
    }

    // Getters and Setters
    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

    public User getPatient() {
        return patient;
    }

    public void setPatient(User patient) {
        this.patient = patient;
    }

    public User getDoctor() {
        return doctor;
    }

    public void setDoctor(User doctor) {
        this.doctor = doctor;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    // Getter and Setter for cost
    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}
