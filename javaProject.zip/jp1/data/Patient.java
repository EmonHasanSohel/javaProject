package data;

public class Patient extends User {
    public Patient(String username, String password, String name, String email, String location, String NID, String dateOfBirth) {
        super(username, password, name, email, "patient", location, NID, dateOfBirth);
    }
}