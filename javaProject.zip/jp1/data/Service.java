package data;

public class Service {
    private String name;
    private double price;
    private boolean available;
    private String description; // New description field

    public Service(String name, double price, boolean available, String description) {
        this.name = name;
        this.price = price;
        this.available = available;
        this.description = description; // Initialize description
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isAvailable() { // Corrected method name for boolean getter
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getDescription() { // Getter for description
        return description;
    }

    public void setDescription(String description) { // Setter for description
        this.description = description;
    }
}
