package data;

public abstract class User {
    private String username;
    private String password;
    private String name;
    private String email;
    private String accountType;
    private String location;
    private String NID;
    private String age;

    public User(String username, String password, String name, String email, String accountType, String location, String NID, String age) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.accountType = accountType;
        this.location = location;
        this.NID = NID;
        this.age = age;
    }

    public String getUsername() {
        return username;
    }

    // public void setUsername(String username) {
    //     this.username = username;
    // }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNID() {
        return NID;
    }

    public void setNID(String NID) {
        this.NID = NID;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String dateOfBirth) {
        this.age = dateOfBirth;
    }

    public String toString() {
        return username + ":" + password + ":" + name + ":" + email + ":" + accountType + ":" + location + ":" + NID + ":" + age;
    }

    public static User fromString(String data) {
        String[] parts = data.split(":");
        if (parts.length != 8) {
            throw new IllegalArgumentException("Invalid data format");
        }

        if(parts[4].equals("patient")) {
            return new Patient(parts[0], parts[1], parts[2], parts[3], parts[5], parts[6], parts[7]);
        } else {
            return new Doctor(parts[0], parts[1], parts[2], parts[3], parts[5], parts[6], parts[7]);
        }

        
    }
}
