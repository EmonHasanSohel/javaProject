package database;

import java.util.ArrayList;
import java.util.List;

import data.Order;

public class ActiveOrdersDatabase {
    public static List<Order> orders =  new ArrayList<>();
}
