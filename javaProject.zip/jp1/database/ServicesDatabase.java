package database;

import data.Service;

public class ServicesDatabase {
    private static Service[] services = new Service[10];

    static {
        services[0] = new Service("CoVID Test", 1230, true, "A doctor will visit to do a Covid Test.");
        services[1] = new Service("Blood Test", 1230, true, "A laboratory test for various health parameters.");
        services[2] = new Service("CoVid Vaccination", 1230, true, "A vaccination service for Covid-19.");
        services[3] = new Service("Pressure Test", 1230, true, "A service to check blood pressure.");
        services[4] = new Service("Diabetes Management", 1500, true, "Guidance and monitoring for diabetes care.");
        services[5] = new Service("Home Physiotherapy", 1800, true, "Personalized physiotherapy sessions at home.");
        services[6] = new Service("Elderly Care", 2000, true, "Comprehensive care services for elderly patients.");
        services[7] = new Service("Wound Care", 1400, true, "Professional wound care and dressing changes at home.");
        services[8] = new Service("Nutritional Consultation", 1600, true, "Dietary advice and meal planning by a nutritionist.");
        services[9] = new Service("Pediatric Care", 1900, true, "Home visits for children's health check-ups and vaccinations.");

    }

    public static Service[] getAll() {
        return ServicesDatabase.services;
    }
}
