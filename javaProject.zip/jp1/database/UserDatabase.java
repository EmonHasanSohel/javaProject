package database;

import data.Doctor;
import data.Patient;
import data.User;
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class UserDatabase {
    private static final String FILE_PATH = "users.txt"; // File to store user data
    private static List<User> users = new ArrayList<>();

    static {
        loadUsers(); // Load users from the file when the class is loaded
    }

    private static void loadUsers() {
        try {
            if (Files.exists(Paths.get(FILE_PATH))) {
                List<String> lines = Files.readAllLines(Paths.get(FILE_PATH));
                for (String line : lines) {
                    User u = User.fromString(line);
                    // u.get
                    users.add(u); // Deserialize each line to User object
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading users: " + e.getMessage());
        }
    }

    private static void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (User user : users) {
                writer.write(user.toString()); // Serialize User object to string and write to file
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving users: " + e.getMessage());
        }
    }

    public static User authenticate(String username, String password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    public static boolean register(String username, String password, String name, String email, String accountType, String location, String NID, String dateOfBirth) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                System.out.println("Username already exists! Please choose a different username.");
                return false; // Username already taken
            }
        }
    
        
        User newUser;
        if(accountType.equals("patient")) {
            newUser = new Patient(username, password, name, email, location, NID, dateOfBirth);
        } else {
            newUser = new Doctor(username, password, name, email, location, NID, dateOfBirth);
        }

        users.add(newUser);
        saveUsers(); // Save updated user list to file
        return true; // User registered successfully
    }

    public static boolean delete(String username) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(username)) {
                users.remove(i); // Remove user from list
                saveUsers(); // Save updated user list to file
                return true; // User successfully deleted
            }
        }
        System.out.println("User not found!");
        return false; // User not found
    }

    public static List<User> getAll() {
        return UserDatabase.users;
    }
}
