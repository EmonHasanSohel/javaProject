package frames;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

import data.*;
import database.UserDatabase;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccountDetailsFrame extends JFrame {
    private JPanel panel2;
	private JPanel panel3;
	private JLabel userNameLabel;
	private JTextField userNameField;
	private JLabel nameLabel;
	private JTextField nameField;
	private JLabel emailLabel;
	private JTextField emailField;
	private JLabel locationLabel;
	private JTextField locationField;
	private JLabel nidLabel;
	private JTextField nidField;
	private JLabel birthdayLabel;
	private JTextField birthdayField;
	private JLabel passLabel;
	private JPasswordField passwordField1;
	private JButton button1;
	private JButton button2;
    public AccountDetailsFrame(User user) {
        panel2 = new JPanel();
		panel3 = new JPanel();
		userNameLabel = new JLabel();
		userNameField = new JTextField();
		nameLabel = new JLabel();
		nameField = new JTextField();
		emailLabel = new JLabel();
		emailField = new JTextField();
		locationLabel = new JLabel();
		locationField = new JTextField();
		nidLabel = new JLabel();
		nidField = new JTextField();
		birthdayLabel = new JLabel();
		birthdayField = new JTextField();
		passLabel = new JLabel();
		passwordField1 = new JPasswordField();
		button1 = new JButton();
		button2 = new JButton();

        // Set default values from the user object
        userNameField.setText(user.getUsername());
        nameField.setText(user.getName());
        emailField.setText(user.getEmail());
        locationField.setText(user.getLocation());
        nidField.setText(user.getNID());
        birthdayField.setText(user.getAge());
        passwordField1.setText(user.getPassword());

        // Set text fields to be non-editable initially
        setEditableFields(false);

        // ActionListener for the "Edit" button
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isEditable = nameField.isEditable();
                if (isEditable) {
                    // user.setUsername(userNameField.getText());
                    System.out.println("aapp");
                    user.setName(nameField.getText());
                    user.setEmail(emailField.getText());
                    user.setLocation(locationField.getText());
                    user.setNID(nidField.getText());
                    user.setAge(birthdayField.getText());
                    user.setPassword(new String(passwordField1.getPassword()));
                    setEditableFields(false);
                    button1.setText("Edit");


                } else {
                    setEditableFields(!isEditable);
                    button1.setText("Apply Edit");
                }
            }

        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UserDatabase.delete(user.getUsername());
                dispose();

                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setSize(900, 600);
                loginFrame.setVisible(true);
            }

        });

		//======== this ========
		Container contentPane = getContentPane();
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));

		//======== panel2 ========
		{
			panel2.setBorder(new EmptyBorder(20, 20, 20, 20));
			// panel2.setBorder (new javax. swing. border. CompoundBorder( new javax .swing .border .TitledBorder (new EmptyBorder( 0, 0, 0, 0) , "JFor\u006dDesi\u0067ner \u0045valu\u0061tion", 
            //     TitledBorder.CENTER, 
            //     TitledBorder.BOTTOM, 
            //     new Font("Dia\u006cog" , Font.BOLD ,
			// 12 ), Color.red), panel2.getBorder())); 
            
            // panel2. addPropertyChangeListener (new java. beans

			// . PropertyChangeListener( ){ @Override public void propertyChange (java .beans .PropertyChangeEvent e) {if ("bord\u0065r" .equals (e .
			// getPropertyName () )) throw new RuntimeException( ); }} );
			panel2.setLayout(new BoxLayout(panel2, BoxLayout.X_AXIS));

			//======== panel3 ========
			{
				panel3.setPreferredSize(new Dimension(90, 76));
				panel3.setMinimumSize(null);
				panel3.setMaximumSize(null);
				panel3.setBorder(new TitledBorder(new LineBorder(Color.lightGray), "Account", TitledBorder.LEADING, TitledBorder.DEFAULT_POSITION, null, Color.darkGray));
				panel3.setLayout(new GridBagLayout());
				((GridBagLayout)panel3.getLayout()).columnWidths = new int[] {127, 188, 0};
				((GridBagLayout)panel3.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
				((GridBagLayout)panel3.getLayout()).columnWeights = new double[] {0.0, 0.0, 1.0E-4};
				((GridBagLayout)panel3.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

				//---- userNameLabel ----
				userNameLabel.setText("Username");
				panel3.add(userNameLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- userNameField ----
				userNameField.setEditable(false);
				panel3.add(userNameField, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- nameLabel ----
				nameLabel.setText("Name");
				panel3.add(nameLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- nameField ----
				nameField.setEditable(false);
				panel3.add(nameField, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- emailLabel ----
				emailLabel.setText("Email");
				panel3.add(emailLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- emailField ----
				emailField.setEditable(false);
				panel3.add(emailField, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- locationLabel ----
				locationLabel.setText("Location");
				panel3.add(locationLabel, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- locationField ----
				locationField.setEditable(false);
				panel3.add(locationField, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- nidLabel ----
				nidLabel.setText("NID");
				panel3.add(nidLabel, new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- nidField ----
				nidField.setEditable(false);
				panel3.add(nidField, new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- birthdayLabel ----
				birthdayLabel.setText("Date of Birth");
				panel3.add(birthdayLabel, new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- birthdayField ----
				birthdayField.setEditable(false);
				panel3.add(birthdayField, new GridBagConstraints(1, 6, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- passLabel ----
				passLabel.setText("Password");
				panel3.add(passLabel, new GridBagConstraints(0, 7, 1, 1, 0.0, 0.0,
					GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
					new Insets(0, 0, 5, 10), 0, 0));

				//---- passwordField1 ----
				passwordField1.setEditable(false);
				panel3.add(passwordField1, new GridBagConstraints(1, 7, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- button1 ----
				button1.setText("Edit");
				panel3.add(button1, new GridBagConstraints(1, 8, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 5, 0), 0, 0));

				//---- button2 ----
				button2.setText("Delete Account");
				button2.setBackground(new Color(0xfff8ee));
				panel3.add(button2, new GridBagConstraints(1, 9, 1, 1, 0.0, 0.0,
					GridBagConstraints.CENTER, GridBagConstraints.BOTH,
					new Insets(0, 0, 0, 0), 0, 0));
			}
			panel2.add(panel3);
		}
		contentPane.add(panel2);
		setSize(590, 610);
		setLocationRelativeTo(getOwner());


        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {

				if(user.getAccountType().equals("patient")) { 
					PatientDashboardFrame frame = new PatientDashboardFrame(user);
					frame.setSize(800, 800);
					frame.setVisible(true);
				} else {
					new LoginFrame().showFrame();
				}

                dispose();
            }
        });
    }

    private void setEditableFields(boolean editable) {
        // userNameField.setEditable(editable);
        nameField.setEditable(editable);
        emailField.setEditable(editable);
        locationField.setEditable(editable);
        nidField.setEditable(editable);
        birthdayField.setEditable(editable);
        passwordField1.setEditable(editable);
    }

	public void showFrame() {
		setSize(450, 450);
		setVisible(true);
	}
}