package frames;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import data.*;
import database.UserDatabase;

import java.awt.*;
import java.awt.event.*;

public class CreateOrderServiceFrame extends JFrame {
    private JPanel padding;
	private JPanel panel1;
	private JLabel serviceNameLabel;
	private JLabel serviceName;
	private JLabel doctorNameLabel;
	private JComboBox<String> comboBox1;
	private JLabel locationLabel;
	private JTextField textField1;
	private JLabel phoneLabel;
	private JTextField textField2;
	private JLabel totalCost;
	private JLabel totalcost;
	private JPanel panel2;
	private JButton button1;

    public CreateOrderServiceFrame(Service service, User user) {
                
        setTitle("Order Service");
        // setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        padding = new JPanel();
		panel1 = new JPanel();
		serviceNameLabel = new JLabel();
		serviceName = new JLabel();
		doctorNameLabel = new JLabel();
		comboBox1 = new JComboBox<>();
		locationLabel = new JLabel();
		textField1 = new JTextField();
		phoneLabel = new JLabel();
		textField2 = new JTextField();
		totalCost = new JLabel();
		totalcost = new JLabel();
		panel2 = new JPanel();
		button1 = new JButton();

        serviceName.setText(service.getName());
        totalcost.setText(Double.toString(service.getPrice()));

        for (User s : UserDatabase.getAll()) {

            if (new String("doctor").equals(s.getAccountType())) {
            System.out.println(s.getLocation());
                
                comboBox1.addItem(s.getName());
            }
        }
		//======== ReceiptFrame ========
		{
			setLayout(new BoxLayout(this.getContentPane(), BoxLayout.X_AXIS));

			//======== padding ========
			{
				padding.setBorder(new EmptyBorder(30, 30, 30, 30));
				padding.setPreferredSize(new Dimension(222, 33));
				padding.setLayout(null);

				//======== panel1 ========
				{
					panel1.setBorder(new TitledBorder(new LineBorder(Color.lightGray), "Order Details", TitledBorder.LEADING, TitledBorder.DEFAULT_POSITION, null, Color.darkGray));
					panel1.setLayout(new GridBagLayout());
					((GridBagLayout)panel1.getLayout()).columnWidths = new int[] {144, 157, 0};
					((GridBagLayout)panel1.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0};
					((GridBagLayout)panel1.getLayout()).columnWeights = new double[] {0.0, 0.0, 1.0E-4};
					((GridBagLayout)panel1.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

					//---- serviceNameLabel ----
					serviceNameLabel.setText("Service name: ");
					panel1.add(serviceNameLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(serviceName, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- doctorNameLabel ----
					doctorNameLabel.setText("Doctor: ");
					panel1.add(doctorNameLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(comboBox1, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- locationLabel ----
					locationLabel.setText("Location: ");
					panel1.add(locationLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(textField1, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- phoneLabel ----
					phoneLabel.setText("Phone: ");
					panel1.add(phoneLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(textField2, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- totalCost ----
					totalCost.setText("Total Cost: ");
					totalCost.setFont(new Font("Segoe UI", Font.BOLD, 12));
					panel1.add(totalCost, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 0, 5), 0, 0));
					panel1.add(totalcost, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
				}
				padding.add(panel1);
				panel1.setBounds(30, 30, 368, 185);

				//======== panel2 ========
				{
					panel2.setBorder(new TitledBorder(new LineBorder(Color.lightGray), "Confirm", TitledBorder.LEADING, TitledBorder.DEFAULT_POSITION, null, Color.darkGray));
					panel2.setLayout(new FlowLayout());

					//---- button1 ----
					button1.setText("Confirm Order");
					panel2.add(button1);
				}
				padding.add(panel2);
				panel2.setBounds(30, 215, 368, 65);
			}

                    


            button1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    User doc = null;
                    for (User s : UserDatabase.getAll()) {

                        if (comboBox1.getSelectedItem().equals(s.getName())) {
                            doc = s;
                            break;
                        }
                    }
                    new PaymentFrame(new Order(service, user, doc, textField1.getText(), textField2.getText(), service.getPrice())).showFrame();
                    dispose();
                }
            });
			add(padding);
		}
    }

    public void showFrame() {
        setSize(450, 600);
        setVisible(true);
    }

}