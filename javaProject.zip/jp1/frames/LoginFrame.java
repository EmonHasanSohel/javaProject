package frames;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import data.*;
import database.UserDatabase;


public class LoginFrame extends JFrame {
	private JPanel padding;
	private JPanel panel1;
	private JLabel userNameLabel;
	private JTextField userNameField;
	private JLabel passwordLabel;
	private JPasswordField passwordField1;
	private JButton loginBtn;
	private JButton registerBtn;
	private JLabel label1;
	private JPanel vSpacer1;

    public LoginFrame() {
        super("Login");

		padding = new JPanel();
		panel1 = new JPanel();
		userNameLabel = new JLabel();
		userNameField = new JTextField();
		passwordLabel = new JLabel();
		passwordField1 = new JPasswordField();
		loginBtn = new JButton();
		registerBtn = new JButton();
		label1 = new JLabel();
		vSpacer1 = new JPanel(null);

		//======== ReceiptFrame ========
		{
			setLayout(new BoxLayout(this.getContentPane(), BoxLayout.X_AXIS));

			//======== padding ========
			{
				padding.setBorder(new EmptyBorder(30, 30, 30, 30));
				padding.setPreferredSize(new Dimension(222, 33));

				padding.setLayout(null);

				//======== panel1 ========
				{
					panel1.setBorder(new LineBorder(Color.lightGray));
					panel1.setLayout(new GridBagLayout());
					((GridBagLayout)panel1.getLayout()).columnWidths = new int[] {119, 157, 0};
					((GridBagLayout)panel1.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0};
					((GridBagLayout)panel1.getLayout()).columnWeights = new double[] {0.0, 0.0, 1.0E-4};
					((GridBagLayout)panel1.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

					panel1.add(vSpacer1, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));


					//---- userNameLabel ----
					userNameLabel.setText("Username");
                    panel1.add(userNameLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
                    GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
                    new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(userNameLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(userNameField, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- passwordLabel ----
					passwordLabel.setText("Password");
					panel1.add(passwordLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(passwordField1, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- loginBtn ----
					loginBtn.setText("Login");
					panel1.add(loginBtn, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- registerBtn ----
					registerBtn.setText("Register");
					panel1.add(registerBtn, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
				}
				padding.add(panel1);
				panel1.setBounds(30, 110, 368, 200);

				//---- label1 ----
				label1.setText("Welcome to Home Hospital!");
				label1.setFont(new Font("Segoe UI", Font.BOLD, 18));
				padding.add(label1);
				label1.setBounds(new Rectangle(new Point(60, 45), label1.getPreferredSize()));
			}
			add(padding);
		}

        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userNameField.getText();
                String password = passwordField1.getText();
                User user = UserDatabase.authenticate(username, password);
                if (user != null) {

					if(user.getAccountType().equals("patient")) {
						new PatientDashboardFrame(user).showFrame();

					} else {
						new AccountDetailsFrame(user).showFrame();

					}


                    dispose();
                } else {
                    // Handle invalid login credentials
                    System.out.println("Invalid login credentials");
                }
            }
        });

        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RegistrationFrame().showFrame();
                dispose();
            }
        });
    }

    public void showFrame() {
        setSize(450, 600);
        setVisible(true);
    }
}