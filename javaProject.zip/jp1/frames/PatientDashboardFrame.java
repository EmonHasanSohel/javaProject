package frames;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import data.*;
import database.ServicesDatabase;

public class PatientDashboardFrame extends JFrame {
    private JList<Service> serviceList;
    private DefaultListModel<Service> listModel;

    public PatientDashboardFrame(User user) {
        setTitle("Service List");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        JButton button1 = new JButton("Account");
        JButton button2 = new JButton("Logout");
        JButton button3 = new JButton("Button 3");

        // Set button size
        button1.setPreferredSize(new Dimension(120, 25));
        button2.setPreferredSize(new Dimension(120, 25));
        button3.setPreferredSize(new Dimension(120, 25));

        buttonPanel.add(button1);
        buttonPanel.add(button2);
        // buttonPanel.add(button3);

        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                new AccountDetailsFrame(user).showFrame();
                dispose();
            }
        });

        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new LoginFrame().showFrame();
                dispose();
            }
        });

        // Create service list
        listModel = new DefaultListModel<>();
        

        JPanel servicePanel = new JPanel();
        servicePanel.setLayout(new GridLayout(12, 1, 5, 5));

        for (Service service : ServicesDatabase.getAll()) {
            if (service != null) {
                // System.out.println("Service:L " + service.getName());
                JPanel serviceInfoPanel = createServicePanel(service, user);
                servicePanel.add(serviceInfoPanel);
            }

        }

        JScrollPane scrollPane = new JScrollPane(servicePanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(400, 100)); // Set preferred size for the scroll pane


        // Add components to the frame
        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createServicePanel(Service service, User user) {
        JPanel panel = new JPanel();
        // panel.setSize(120, 400);
        panel.setLayout(null);
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        
        JLabel nameLabel = new JLabel("Name: " + service.getName());
        nameLabel.setBounds(20, 10, 500, 30);

        JLabel priceLabel = new JLabel("Price: BDT" + service.getPrice());
        priceLabel.setBounds(600, 22, 500, 30);

        JLabel descriptionLabel = new JLabel(service.getDescription()) ;
        descriptionLabel.setBounds(20, 30, 500, 30);
        descriptionLabel.setForeground(Color.decode("#595959"));

        JButton orderBtn = new JButton("Order");
        orderBtn.setBounds(20, 75, 70, 25);
        
        panel.add(nameLabel);
        panel.add(priceLabel);
        panel.add(orderBtn);
        panel.add(descriptionLabel);

        panel.setPreferredSize(new Dimension(640, 130));

        orderBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (service != null) {

                    new CreateOrderServiceFrame(service, user).showFrame();
                    dispose();
                }
            }
        });



        return panel;
    }

    public void showFrame() {
        setSize(780, 500);
        setVisible(true);
    }
}
