package frames;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.*;

import data.Order;
import database.ActiveOrdersDatabase;

public class PaymentFrame extends JFrame {
	private JPanel padding;
	private JPanel panel1;
	private JLabel serviceNameLabel;
	private JLabel serviceName;
	private JLabel doctorNameLabel;
	private JLabel doctorName;
	private JLabel locationLabel;
	private JLabel location;
	private JLabel phoneLabel;
	private JLabel phone;
	private JLabel totalCostLabel;
	private JLabel totalcost;
	private JPanel panel2;
	private JLabel paidlabel;

	private JButton bkashButton;
	private JButton nagadButton;
	private JButton bankButton;

    public PaymentFrame(Order order) {
		padding = new JPanel();
		panel1 = new JPanel();
		serviceNameLabel = new JLabel();
		serviceName = new JLabel();
		doctorNameLabel = new JLabel();
		doctorName = new JLabel();
		locationLabel = new JLabel();
		location = new JLabel();
		phoneLabel = new JLabel();
		phone = new JLabel();
		totalCostLabel = new JLabel();
		totalcost = new JLabel();
		panel2 = new JPanel();
		paidlabel = new JLabel();

		bkashButton = new JButton("Bkash");
		nagadButton = new JButton("Nagad");
		bankButton = new JButton("Bank");
        
        serviceName.setText(order.getService().getName());
        doctorName.setText(order.getDoctor().getName());
        location.setText(order.getLocation());
        phone.setText(order.getPhone());
        totalcost.setText(Double.toString(order.getCost()));


		//======== ReceiptFrame ========
		{
			setLayout(new BoxLayout(this.getContentPane(), BoxLayout.X_AXIS));

			//======== padding ========
			{
				padding.setBorder(new EmptyBorder(30, 30, 30, 30));
				padding.setPreferredSize(new Dimension(222, 33));
				padding.setLayout(null);

				//======== panel1 ========
				{
					panel1.setBorder(new TitledBorder(new LineBorder(Color.lightGray), "Order Details", TitledBorder.LEADING, TitledBorder.DEFAULT_POSITION, null, Color.darkGray));
					panel1.setLayout(new GridBagLayout());
					((GridBagLayout)panel1.getLayout()).columnWidths = new int[] {144, 157, 0};
					((GridBagLayout)panel1.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0};
					((GridBagLayout)panel1.getLayout()).columnWeights = new double[] {0.0, 0.0, 1.0E-4};
					((GridBagLayout)panel1.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

					//---- serviceNameLabel ----
					serviceNameLabel.setText("Service name");
					panel1.add(serviceNameLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(serviceName, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- doctorNameLabel ----
					doctorNameLabel.setText("Doctor");
					panel1.add(doctorNameLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(doctorName, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- locationLabel ----
					locationLabel.setText("Location");
					panel1.add(locationLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(location, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- phoneLabel ----
					phoneLabel.setText("Phone");
					panel1.add(phoneLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 5, 5), 0, 0));
					panel1.add(phone, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 5, 0), 0, 0));

					//---- totalCost ----
					totalCostLabel.setText("Total Cost");
					totalCostLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
					panel1.add(totalCostLabel, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 0, 5), 0, 0));
					panel1.add(totalcost, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
				}
				padding.add(panel1);
				panel1.setBounds(30, 30, 368, 130);

				//======== panel2 ========
				{
					panel2.setBorder(new TitledBorder(new LineBorder(Color.lightGray), "Payment", TitledBorder.LEADING, TitledBorder.DEFAULT_POSITION, null, Color.darkGray));
					panel2.setLayout(new FlowLayout());

					//---- paidlabel ----
					paidlabel.setText("PAID!");
					paidlabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
					paidlabel.setVisible(false);
					panel2.add(paidlabel);

					panel2.add(bkashButton);
					panel2.add(nagadButton);
					panel2.add(bankButton);

					bkashButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							paymentSuccessful(order);
						}
					});
			
					nagadButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							paymentSuccessful(order);
						}
					});
			
					bankButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							paymentSuccessful(order);
						}
					});
				}
				padding.add(panel2);
				JButton dash = new JButton("Go back");
				dash.setBounds(120, 260, 180, 30);

				dash.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new PatientDashboardFrame(order.getPatient()).showFrame();
						dispose();
					}
				});

				padding.add(dash);
				panel2.setBounds(30, 175, 368, 70);
			}
			add(padding);
			// ReceiptFrame.pack();
			// ReceiptFrame.setLocationRelativeTo(ReceiptFrame.getOwner());
		}
    }

    public void showFrame() {
        setSize(450, 600);
        setVisible(true);
    }
	public void paymentSuccessful(Order o) {
		paidlabel.setVisible(true);
		bkashButton.setVisible(false);
		nagadButton.setVisible(false);
		bankButton.setVisible(false);

		ActiveOrdersDatabase.orders.add(o);
	}
}
