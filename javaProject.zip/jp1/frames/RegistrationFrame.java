package frames;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import data.*;
import database.UserDatabase;

public class RegistrationFrame extends JFrame {
	private JPanel padding;
	private JPanel panel1;
	private JPanel vSpacer1;
	private JLabel userNameLabel;
	private JTextField userNameField;
	private JLabel passwordLabel;
	private JPasswordField passwordField1;
	private JLabel label2;
	private JTextField textField1;
	private JLabel label3;
	private JTextField textField2;
	private JLabel label4;
	private JTextField textField3;
	private JLabel label6;
	private JTextField textField4;
	private JLabel label7;
	private JTextField textField5;
	private JLabel label5;
	private JComboBox accountTypeChoice;
	private JButton registerBtn;
	private JLabel label1;

    public RegistrationFrame() {
        super("Registration");
        padding = new JPanel();
		panel1 = new JPanel();
		vSpacer1 = new JPanel(null);
		userNameLabel = new JLabel();
		userNameField = new JTextField();
		passwordLabel = new JLabel();
		passwordField1 = new JPasswordField();
		label2 = new JLabel();
		textField1 = new JTextField();
		label3 = new JLabel();
		textField2 = new JTextField();
		label4 = new JLabel();
		textField3 = new JTextField();
		label6 = new JLabel();
		textField4 = new JTextField();
		label7 = new JLabel();
		textField5 = new JTextField();
		label5 = new JLabel();
		accountTypeChoice = new JComboBox<String>();
		registerBtn = new JButton();
		label1 = new JLabel();

		//======== ReceiptFrame ========
		{
			setLayout(new BoxLayout(this.getContentPane(), BoxLayout.X_AXIS));

			//======== padding ========
			{
				padding.setBorder(new EmptyBorder(30, 30, 30, 30));
				padding.setPreferredSize(new Dimension(222, 33));

				padding.setLayout(null);

				//======== panel1 ========
				{
					panel1.setBorder(new LineBorder(Color.lightGray));
					panel1.setLayout(new GridBagLayout());
					((GridBagLayout)panel1.getLayout()).columnWidths = new int[] {119, 157, 0};
					((GridBagLayout)panel1.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
					((GridBagLayout)panel1.getLayout()).columnWeights = new double[] {0.0, 0.0, 1.0E-4};
					((GridBagLayout)panel1.getLayout()).rowWeights = new double[] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};
					panel1.add(vSpacer1, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 11, 0), 0, 0));

					//---- userNameLabel ----
					userNameLabel.setText("Username");
					panel1.add(userNameLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(userNameField, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- passwordLabel ----
					passwordLabel.setText("Password");
					panel1.add(passwordLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(passwordField1, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- label2 ----
					label2.setText("Full Name");
					panel1.add(label2, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(textField1, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- label3 ----
					label3.setText("Email");
					panel1.add(label3, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(textField2, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- label4 ----
					label4.setText("Location");
					panel1.add(label4, new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(textField3, new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- label6 ----
					label6.setText("NID");
					panel1.add(label6, new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(textField4, new GridBagConstraints(1, 6, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- label7 ----
					label7.setText("Age");
					panel1.add(label7, new GridBagConstraints(0, 7, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));
					panel1.add(textField5, new GridBagConstraints(1, 7, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- label5 ----
					label5.setText("Account Type");
					panel1.add(label5, new GridBagConstraints(0, 8, 1, 1, 0.0, 0.0,
						GridBagConstraints.EAST, GridBagConstraints.VERTICAL,
						new Insets(0, 0, 10, 15), 0, 0));


                    accountTypeChoice.addItem("patient");
                    accountTypeChoice.addItem("doctor");
					panel1.add(accountTypeChoice, new GridBagConstraints(1, 8, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 10, 0), 0, 0));

					//---- registerBtn ----
					registerBtn.setText("Register");
					panel1.add(registerBtn, new GridBagConstraints(1, 9, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));
					
					JButton gb = new JButton("Go to Login!");
					panel1.add(gb, new GridBagConstraints(1, 11, 1, 1, 0.0, 0.0,
						GridBagConstraints.CENTER, GridBagConstraints.BOTH,
						new Insets(0, 0, 0, 0), 0, 0));

						gb.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								new LoginFrame().showFrame();
								dispose();
							}
						});
				}
				padding.add(panel1);
				panel1.setBounds(30, 110, 370, 330);

				//---- label1 ----
				label1.setText("Please Register to continue!");
				label1.setFont(new Font("Segoe UI", Font.BOLD, 18));
				padding.add(label1);
				label1.setBounds(new Rectangle(new Point(100, 45), label1.getPreferredSize()));
			}
			add(padding);
		}

        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userNameField.getText();
                String password = passwordField1.getText();
                String name = textField1.getText();
                String email = textField2.getText();
                String location = textField3.getText();
                String NID = textField4.getText();
                String age = textField5.getText();
                String accountType = (String) accountTypeChoice.getSelectedItem();

				if (username.isEmpty() || password.isEmpty() || name.isEmpty() || email.isEmpty() || location.isEmpty() || NID.isEmpty() || age.isEmpty() || accountType.isEmpty()) {
					JOptionPane.showMessageDialog(RegistrationFrame.this, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
                if (UserDatabase.register(username, password, name, email, accountType, location, NID, age)) {
                    LoginFrame loginFrame = new LoginFrame();
                    loginFrame.showFrame();
                    dispose();
                } else {
                    // Handle registration failure
                    System.out.println("Registration failed");
                }
            }
        });
    }

    public void showFrame() {
        setSize(450, 550);
        setVisible(true);
    }
}
